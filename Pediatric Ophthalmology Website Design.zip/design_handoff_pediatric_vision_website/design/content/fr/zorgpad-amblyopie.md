Parcours de soins amblyopie

Qu’est-ce que l’amblyopie ?
L’amblyopie, aussi appelée « œil paresseux », est une baisse de l’acuité visuelle d’un œil ou, plus rarement, des deux yeux, qui ne peut pas être entièrement corrigée par des lunettes.
L’amblyopie apparaît dans la petite enfance, pendant la période critique du développement visuel. Cette période commence à la naissance et dure jusqu’à environ 10 ans, pendant le développement du cortex visuel. Une expérience visuelle anormale peut perturber ce développement pour un œil, ou parfois les deux, et entraîner une amblyopie unilatérale ou bilatérale. L’amblyopie est réversible si elle est reconnue et traitée à temps ; non traitée, elle entraîne une déficience visuelle permanente.

Causes principales
> 1. Amblyopie strabique – due à un strabisme, l’image d’un œil étant supprimée.
> 2. Amblyopie réfractive (anisométropique) – due à une différence de correction entre les deux yeux.
> 3. Amblyopie de privation – due à un obstacle visuel (p. ex. cataracte congénitale, ptosis).

1. Détection et dépistage
- Âge : le dépistage précoce est essentiel, idéalement avant 6 ans. L’amblyopie unilatérale passe souvent inaperçue pour l’entourage, car la vision avec les deux yeux ne provoque pas de plaintes spontanées.
- Qui la détecte ?
  > L’ONE / Kind en Gezin lors des visites de routine
  > Le CLB / PSE
  > Le médecin généraliste ou le pédiatre en cas de plaintes visuelles
  > Les parents qui remarquent un strabisme ou un comportement visuel inhabituel
- Signes d’alerte : strabisme, fermeture d’un œil, position anormale de la tête, vision floue, plaintes lorsqu’on cache un œil.
- L’amblyopie unilatérale ne provoque pas de plaintes spontanées et passe souvent inaperçue pour l’entourage !

2. Orientation vers un spécialiste
- Quand ?
  > Test de dépistage anormal, antécédents familiaux d’amblyopie ou de strabisme
  > Reflet rouge anormal
  > Toujours en cas de suspicion de strabisme ou de différence d’acuité entre les deux yeux
  > En présence de facteurs de risque : strabisme familial, cataracte congénitale, forte correction

3. Diagnostic au cabinet d’ophtalmologie
- Examen ophtalmologique complet : acuité visuelle adaptée à l’âge, fond d’œil, motilité, tests de stéréoscopie.
- Réfraction sous cycloplégie : détection des troubles de la réfraction (hypermétropie, anisométropie, astigmatisme).
- Examens complémentaires : uniquement en cas d’évolution atypique ou de suspicion de cause organique.

4. Traitement
- Correction du trouble de la réfraction
  > Première étape : prescrire les bonnes lunettes.
  > La vision s’améliore souvent nettement en 4 à 12 semaines.
- Traitement par occlusion
  > Cacher le bon œil pour stimuler l’œil paresseux.
  > Durée et intensité selon l’âge et la sévérité.
  > Alternative en cas de difficultés d’observance : gouttes d’atropine dans le bon œil
- Traitement de la cause sous-jacente
  > Chirurgie du strabisme si le strabisme persiste après la correction optique.
  > Chirurgie en cas de cataracte/ptosis.

5. Suivi
- Fréquence :
  > Tous les 2 à 3 mois en cas d’amblyopie profonde, tous les 6 mois en cas d’amblyopie légère ou de facteurs de risque importants, une fois par an chez les enfants stables
  > Jusqu’à stabilisation et acuité visuelle maximale
- Points de contrôle :
  > Acuité visuelle des deux yeux
  > Observance du traitement (durée d’occlusion, acceptation)
  > Paramètres orthoptiques (angle du strabisme, fusion, vision stéréoscopique)

6. Fin du traitement
- Objectif : gain visuel maximal avant 8 à 10 ans
- Contrôle annuel chez les patients à risque (fortes corrections, strabisme familial).

7. Rôle du médecin généraliste et de la première ligne
- Rester attentif aux plaintes visuelles, aux comportements visuels inhabituels et aux problèmes familiaux
- Orienter à temps en cas de suspicion d’anomalie.
- Soutenir les parents dans l’observance du traitement (occlusion, port des lunettes).
- Reconnaître l’impact psychosocial (harcèlement, refus du traitement, familles socialement vulnérables).
