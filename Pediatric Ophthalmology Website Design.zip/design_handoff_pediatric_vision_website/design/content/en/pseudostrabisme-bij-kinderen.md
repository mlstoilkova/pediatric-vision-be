Pseudostrabismus (apparent squint) in children

It can be worrying for parents when their baby or young child seems to squint. In many cases, however, it is pseudostrabismus: an apparent squint, while the eyes are in fact properly aligned.

What is pseudostrabismus?
With pseudostrabismus the eyes appear misaligned, while anatomically and functionally they are aligned. It is an optical illusion, not a real eye problem.

What causes pseudostrabismus?
Pseudostrabismus is usually caused by typical facial features of young children, such as:
- a broad or flat bridge of the nose
- epicanthal folds (extra skin folds at the inner corner of the eyelids)
- the ratio between the white of the eye and the iris in babies

These features can give the impression that one eye turns inwards or outwards, while both eyes work together correctly.

Is pseudostrabismus dangerous?
No. Pseudostrabismus does not affect vision and does not lead to a lazy eye (amblyopia). No treatment is needed.

Does pseudostrabismus go away by itself?
Yes, in most cases. As the child’s face grows and the bridge of the nose becomes narrower, the apparent squint usually disappears spontaneously, often by the age of 2 to 3.

How is it different from a real squint?
With real strabismus the eyes are actually misaligned. This can affect vision and sometimes requires treatment. That is why it is important that an ophthalmologist distinguishes between pseudostrabismus and a real squint.
During the examination, the ophthalmologist looks at the light reflexes in both eyes, among other things, and assesses the eye position and visual development.

When is an eye examination advisable?
A check-up with an ophthalmologist is recommended:
- if you are unsure about the eye position
- if the squint increases
- if there is a family history of strabismus
- if a child seems to prefer one eye
- if there are other questions about vision or development

In summary
- Pseudostrabismus = apparent squint
- The eyes are correctly aligned
- Harmless and usually temporary
- An eye examination is important to rule out real abnormalities

Do you have questions or doubts about your child’s eye position? A paediatric eye examination gives clarity and reassurance.
